//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by USBBootloader.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USBBOOTLOADER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_RESET_DEVICE         1007
#define IDC_STATIC_VERSION              1008
#define IDC_STATIC_CRC                  1009
#define IDC_STATIC_DEVICECODE           1010
#define IDC_STATIC_STATUS0              1011
#define IDC_STATIC_DEVICECODE_HEXFILE   1011
#define IDC_STATIC_STATUS1              1012
#define IDC_STATIC_STATUS2              1013
#define IDC_STATIC_STATUS4              1015
#define IDC_STATIC_STATUS6              1017
#define IDC_COMBO_DEVICES               1018
#define IDC_BUTTON_REFRESH              1019
#define IDC_BUTTON_OPEN                 1020
#define IDC_EDIT_FILE                   1022
#define IDC_BUTTON_BROWSE               1023
#define IDC_BUTTON_LOAD                 1024
#define IDC_BUTTON_DOWNLOAD             1024
#define IDC_PROGRESS1                   1026
#define ID_BUTTON_HELP                  1035
#define IDC_BUTTON_HELP                 1035
#define IDC_STATIC_NUM_USBX_DEVS        1036
#define IDC_STATIC_NUM_BL_DEVS          1037
#define IDC_STATIC_BL_SW_VER            1038
#define IDC_STATIC_USBX_DLL_VER         1039
#define IDC_STATIC_USBX_DRIVER_VER      1040
#define IDC_STATIC_BL_FW_VER            1041
#define IDC_STATIC_USBX_FWLIB_VER       1042
#define IDC_STATIC_DEVCODE_DESC         1043
#define IDC_STATIC_USB_SERIAL_STRING    1044
#define IDC_STATIC_SIGNATURE_STATUS     1045
#define IDC_STATIC_ABOUT_BL_VER         1045
#define IDC_STATIC_APP_FW_VER           1046
#define IDC_STATIC_APP_FW_VER_HEX_FILE  1047
#define IDC_STATIC_DEVCODE_DESC_HEXFILE 1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
